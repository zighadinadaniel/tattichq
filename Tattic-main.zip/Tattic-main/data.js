// javascript
const items=[
{
    id:1,
    name:"Ash Varsity Jacket",
    colors:{
        1:"Black",
        2:"White"
    },
    image:"images/ash-varsity-jacket.jpg",
    price:35
    
},


{
    id:2,
    name:"Tattic Jacket",
    colors:{
        1:"Black",
        2:"White"
    },
    image:"images/tattic-jacket.jpg",
    price:32
    
},


{
    id:3,
    name:"Atlete fashion Jacket",
    colors:{
        1:"Black",
        2:"Brown"
    },
    image:"images/atlete-fashion-Jacket.jpg",
    price:75
    
},

{
    id:4,
    name:"Camo Jacket",
    colors:{
        1:"Army Green"
    },
    image:"images/camo-jacket.jpg",
    price:35
    
},


{
    id:4,
    name:"Tattic Sleeveless Jacket",
    colors:{
        1:"Brown"
    },
    image:"images/tattic-sleeveless.jpg",
    price:50
    
},

{
    id:5,
    name:"Plain Pants",
    colors:{
        1:"Brown"
    },
    image:"images/plain-pants.jpg",
    price:50
    
},

{
    id:6,
    name:"Ash Pants",
    colors:{
        1:"Black",
        2:"White",
        3:"Blue"
    },
    image:"images/ash-pants.jpg",
    price:50
    
},

{
    id:7,
    name:"Ash Pants",
    colors:{
        1:"Black",
        2:"White",
        3:"Blue"
    },
    image:"images/ash-pants.jpg",
    price:50
    
},

{
    id:8,
    name:"Ash Pants",
    colors:{
        1:"Black",
        2:"White",
        3:"Blue"
    },
    image:"images/ash-pants.jpg",
    price:50
    
}


]




export default items